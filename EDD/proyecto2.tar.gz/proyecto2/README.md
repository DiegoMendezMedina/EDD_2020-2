Proyecto entregado fuera de la fecha estipulada.	
## Estructuras de datos. Proyecto2 Graficador. <h2>

**Diego Mendez Medina**
*420004358*

Identificadores valido para graficar las estructuras:
	 Pila ...seguido de elementos y/o caracteres (no validos para la estructura).
	 
	 Cola ...seguido de elementos y/o caracteres (no validos para la estructura).
	 
	 Lista ...seguido de elementos y/o caracteres (no validos para la estructura).
	 
	 ArbolBinarioOrdenado ...seguido de elementos y/o caracteres (no validos para la estructura).
	 
	 ArbolBinarioCompleto ...seguido de elementos y/o caracteres (no validos para la estructura).
	 
	 ArbolRojinegro ...seguido de elementos y/o caracteres (no validos para la estructura).

	 ArbolAVL ...seguido de elementos y/o caracteres (no validos para la estructura).

	 MonticuloMinimo ...seguido de elementos y/o caracteres (no validos para la estructura).

	 Grafica ...seguido de un numero par de elementos y/o caracteres (no validos para la estructura).


